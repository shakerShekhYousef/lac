<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sections.partials.header', [
        'name' =>__('Show Answer'),
        'description' => __('Here you can Show Answer'),
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Show ََanswer'), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Answer'), false); ?></h6>
                            <div class="form-group">
                                <label for="content">answer</label>
                                <textarea name="description" type="text"
                                          class="form-control form-control-alternative"
                                          id="content"
                                          placeholder="Description"
                                          required><?php echo e($answer->content, false); ?></textarea>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['name' => __('Show Answer')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/answers/show.blade.php ENDPATH**/ ?>