<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('lastNews.partials.header', [
        'title' => "Post Title ". $post->title,
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__($post->title), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">

                        <div class="form-group">
                            <label for="title">Title</label>
                            <input name="title" type="text" class="form-control" id="title"
                                   placeholder="<?php echo e($post->title, false); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="post">Post</label>
                            <textarea name="body" class="form-control" id="post" rows="3"
                                      readonly><?php echo e($post->body, false); ?></textarea>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group form-file-upload form-file-multiple">
                                <label for="">Image</label>
                                <div class="form-group">
                                    <img src="/storage/images/posts/<?php echo e($post->image, false); ?>"
                                         style="height: 200px;width: 200px">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Show Post')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/lastNews/show.blade.php ENDPATH**/ ?>