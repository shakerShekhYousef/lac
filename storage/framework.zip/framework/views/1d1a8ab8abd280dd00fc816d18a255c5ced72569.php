<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-8">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year, false); ?> All Rights Reserved | Designed and Developed by <a href="https://alifouad91.com/" class="font-weight-bold ml-1" target="_blank">Ali Fouad Group</a>
        </div>
    </div>
</div>
<?php /**PATH D:\Digital Edge Projects\chat\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>