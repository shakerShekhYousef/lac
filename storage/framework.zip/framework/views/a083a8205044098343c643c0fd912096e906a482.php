<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' =>__('Show Request Edit'),
        'description' => __('Show Edit Request'),
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Show Edit Request'), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('user.update',$user), false); ?>" method="post">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input value="<?php echo e($change->id, false); ?>" name="change_id" hidden>
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('User information'), false); ?></h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Name'), false); ?></label>
                                        <input type="text" name="name" id="input-name"
                                               class="form-control form-control-alternative"
                                               placeholder="<?php echo e($change->name, false); ?>"
                                               value="<?php echo e($change->name, false); ?>"
                                               readonly autofocus>
                                        <small class="font-weight-light"><?php echo e($user->name, false); ?></small>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('E-mail'), false); ?></label>
                                        <input type="text" name="email" id="input-email"
                                               class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e($change->email, false); ?>"
                                               value="<?php echo e($change->email, false); ?>"
                                               readonly autofocus>
                                        <small class="font-weight-light"><?php echo e($user->email, false); ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-code"><?php echo e(__('Code'), false); ?></label>
                                        <input type="text" name="code" id="input-code"
                                               class="form-control form-control-alternative"
                                               placeholder="<?php echo e($change->code ? $change->code : "Nan", false); ?>"
                                               value="<?php echo e($change->code ? $change->code : "Nan", false); ?>"
                                               readonly autofocus>
                                        <small class="font-weight-light"><?php echo e($user->code, false); ?></small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label"
                                               for="input-national"><?php echo e(__('National Number'), false); ?></label>
                                        <input type="text" name="national_number" id="input-national"
                                               class="form-control form-control-alternative<?php echo e($errors->has('national_number') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e($change->national_number ? $change->national_number : "Nan", false); ?>"
                                               value="<?php echo e($change->national_number, false); ?>"
                                               readonly autofocus >
                                        <small class="font-weight-light"><?php echo e($user->national_number, false); ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="roleSelect">Role</label>
                                            <select name="role_id" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="roleSelect"
                                                    readonly>
                                                <option selected value="<?php echo e($change->role->name, false); ?>"
                                                        disabled><?php echo e($change->role->name, false); ?></option>
                                            </select>
                                            <small class="font-weight-light"><?php echo e($user->role->name, false); ?></small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : '', false); ?>">
                                        <div class="form-group">
                                            <label for="statusSelect">Status</label>
                                            <select name="status" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="statusSelect"
                                                    readonly>
                                                <option selected
                                                        value="<?php echo e($change->status, false); ?>"><?php echo e($change->status ? $change->status : 'Nan', false); ?></option>
                                            </select>
                                            <small class="font-weight-light"><?php echo e($user->status, false); ?></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group form-file-upload form-file-multiple">
                                        <label for="">Image</label>
                                        <div class="form-group">
                                            <img src="/storage/images/users/<?php echo e($change->image, false); ?>"
                                                 style="width: 200px;height: 200px">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group form-file-upload form-file-multiple">
                                        <label for="">old Image</label>
                                        <div class="form-group">
                                            <img src="/storage/images/users/<?php echo e($user->image, false); ?>"
                                                 style="width: 200px;height: 200px">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input value="<?php echo e($change->image, false); ?>" name="image" hidden>
                            <div class="text-center">
                                <button type="submit"
                                        class="btn btn-success mt-4"><?php echo e(__('Approve the request'), false); ?></button>
                            </div>
                            <div class="text-center mt-4">
                                <form action="<?php echo e(route('deleteRequest',$change->id), false); ?>" method="post"></form>
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger"><?php echo e(__('Delete the request'), false); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Show Request Edit')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/users/showRequest.blade.php ENDPATH**/ ?>