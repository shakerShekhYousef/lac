<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' =>__('Create New User'),
        'description' => __('Here you can create new user'),
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Create New User'), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('user.store'), false); ?>" autocomplete="off"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('User information'), false); ?></h6>
                            <div class="col-12">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('status'), false); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-12">
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?php echo e($error, false); ?>

                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Name'), false); ?></label>
                                        <input type="text" name="name" id="input-name"
                                               class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('Name'), false); ?>"
                                               required autofocus>
                                        <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('E-mail'), false); ?></label>
                                        <input type="text" name="email" id="input-email"
                                               class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('E-mail'), false); ?>" required autofocus>
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label"
                                               for="input-password"><?php echo e(__('Password'), false); ?></label>
                                        <input type="password" name="password" id="input-password"
                                               class="form-control form-control-alternative<?php echo e($errors->has('password') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('Password'), false); ?>"
                                               required autofocus>
                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('confirm_password') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label"
                                               for="input-password-confirmation"><?php echo e(__('Confirm Password'), false); ?></label>
                                        <input type="password" name="password_confirmation"
                                               id="input-password-confirmation"
                                               class="form-control form-control-alternative<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('Confirm Password'), false); ?>" required autofocus>
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password_confirmation'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('code') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label" for="input-code"><?php echo e(__('Code'), false); ?></label>
                                        <input type="text" name="code" id="input-code"
                                               class="form-control form-control-alternative<?php echo e($errors->has('code') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('Code'), false); ?>"
                                               required autofocus>
                                        <?php if($errors->has('code')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('code'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('national_number') ? ' has-danger' : '', false); ?>">
                                        <label class="form-control-label"
                                               for="input-national"><?php echo e(__('National Number'), false); ?></label>
                                        <input type="text" name="national_number" id="input-national"
                                               class="form-control form-control-alternative<?php echo e($errors->has('national_number') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e(__('National Number'), false); ?>"
                                               required autofocus>
                                        <?php if($errors->has('national_number')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('national_number'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('role_id') ? ' has-danger' : '', false); ?>">
                                        <div class="form-group">
                                            <label for="roleSelect">Role</label>
                                            <select name="role_id" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="roleSelect">
                                                <option selected value="">Choose Role</option>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id, false); ?>"><?php echo e($role->name, false); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php if($errors->has('role_id')): ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('role_id'), false); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : '', false); ?>">
                                        <div class="form-group">
                                            <label for="statusSelect">status</label>
                                            <select name="status" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="statusSelect">
                                                <option selected value="">Choose status</option>
                                                <option value="active">active</option>
                                                <option value="disactive">disactive</option>
                                                <option value="congealed">congealed</option>
                                                <option value="expired">expired</option>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if($errors->has('status')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('status'), false); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group form-file-upload form-file-multiple">
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <label for="image">Insert Image</label>
                                                <input name="image" type="file" class="custom-file-label" id="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-success btn-lg ">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Create User')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/users/create.blade.php ENDPATH**/ ?>