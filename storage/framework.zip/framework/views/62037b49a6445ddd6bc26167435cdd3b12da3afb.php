<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sections.partials.header', [
        'name' => "Section Name ". $section->name,
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__($section->name), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="title">Name</label>
                            <input name="title" type="text" class="form-control" id="title"
                                   placeholder="<?php echo e($section->name, false); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="translate">Translate</label>
                            <textarea name="translate" class="form-control" id="post" rows="3"
                                      readonly><?php echo e($section->translate, false); ?>

                            </textarea>
                        </div>
                        <div class="form-group">
                            <label for="conversation">Conversation</label>
                            <textarea name="conversation" class="form-control" id="post" rows="3"
                                      readonly><?php echo e($section->conversation, false); ?>

                            </textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Show Section')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/sections/show.blade.php ENDPATH**/ ?>