<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sections.partials.header', [
        'name' =>__('Create New Section'),
        'description' => __('Here you can create new section'),
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Create New section'), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('section.store'), false); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('POST'); ?>
                            <?php echo csrf_field(); ?>
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Section information'), false); ?></h6>
                            <div class="col-12">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('status'), false); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-12">
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?php echo e($error, false); ?>

                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : '', false); ?>">
                                <label for="name">name</label>
                                <input name="name" type="text"
                                       class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : '', false); ?>" id="name"
                                       placeholder="name"
                                       required>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name'), false); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('translate') ? ' has-danger' : '', false); ?>">
                                <label for="translate">Translate</label>
                                <textarea name="translate" class="form-control<?php echo e($errors->has('translate') ? ' is-invalid' : '', false); ?>" id="post" rows="3" required></textarea>
                                <?php if($errors->has('translate')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('translate'), false); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('conversation') ? ' has-danger' : '', false); ?>">
                                <label for="post">Conversation</label>
                                <textarea name="conversation" class="form-control<?php echo e($errors->has('conversation') ? ' is-invalid' : '', false); ?>" id="post" rows="3" required></textarea>
                                <?php if($errors->has('conversation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('conversation'), false); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-success btn-lg ">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['name' => __('Create Section')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/sections/create.blade.php ENDPATH**/ ?>