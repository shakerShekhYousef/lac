<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center">
    <!-- Mask -->
    <span class="mask bg-gradient-orange opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-12 <?php echo e($class ?? '', false); ?>">
                <h1 class="display-2 text-white"><?php echo e($name, false); ?></h1>
                <?php if(isset($description) && $description): ?>
                    <p class="text-white mt-0 mb-5"><?php echo e($description, false); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Digital Edge Projects\chat\resources\views/about/partials/header.blade.php ENDPATH**/ ?>