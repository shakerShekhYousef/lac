<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' =>__('Create New User'),
        'description' => __('Here you can create new user'),
        'class' => 'col-lg-12'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                <div class="card card-profile shadow">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 order-lg-2">
                            <div class="card-profile-image">
                                <a href="#">
                                    <img src="/storage/images/users/<?php echo e($user->image, false); ?>" class="rounded-circle">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                        <div class="d-flex justify-content-between">
                        </div>
                    </div>
                    <div class="card-body pt-0 pt-md-4">
                        <div class="row">
                            <div class="col">
                                <div class="card-profile-stats d-flex justify-content-center mt-md-5">

                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <h3>
                                <?php echo e($user->name, false); ?><small class="font-weight-light"> , <?php echo e($user->role->name, false); ?></small>
                            </h3>
                            <div class="h5 font-weight-300">
                                <i class="ni location_pin mr-2"></i><?php echo e($user->status, false); ?>

                            </div>
                            <h5>
                                <small class="font-weight-light">  <?php echo e($user->email, false); ?></small>
                            </h5>
                            <hr class="my-4" />
                            <h3>
                                Code<small class="font-weight-light"> : <?php echo e($user->code, false); ?></small>
                            </h3>
                            <h3>
                                National Number<small class="font-weight-light"> : <?php echo e($user->national_number, false); ?></small>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Show User'), false); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form>
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('User information'), false); ?></h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Name'), false); ?></label>
                                        <input type="text" name="name" id="input-name"
                                               class="form-control form-control-alternative"
                                               placeholder="<?php echo e($user->name, false); ?>"
                                               readonly autofocus>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('E-mail'), false); ?></label>
                                        <input type="text" name="email" id="input-email"
                                               class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e($user->email, false); ?>" readonly autofocus>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label" for="input-code"><?php echo e(__('Code'), false); ?></label>
                                        <input type="text" name="code" id="input-code"
                                               class="form-control form-control-alternative"
                                               placeholder="<?php echo e($user->code ? $user->code : "Nan", false); ?>"
                                               readonly autofocus>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-control-label"
                                               for="input-national"><?php echo e(__('National Number'), false); ?></label>
                                        <input type="text" name="national_number" id="input-national"
                                               class="form-control form-control-alternative<?php echo e($errors->has('national_number') ? ' is-invalid' : '', false); ?>"
                                               placeholder="<?php echo e($user->national_number ? $user->national_number : "Nan", false); ?>"
                                               readonly autofocus>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="roleSelect">Role</label>
                                            <select name="role_id" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="roleSelect" readonly>
                                                <option selected value=""><?php echo e($user->role->name, false); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : '', false); ?>">
                                        <div class="form-group">
                                            <label for="statusSelect">Status</label>
                                            <select name="status" class="form-control selectpicker"
                                                    data-style="btn btn-link"
                                                    id="statusSelect " readonly>
                                                <option selected
                                                        value=""><?php echo e($user->status ? $user->status : 'Nan', false); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group form-file-upload form-file-multiple">
                                        <label for="">Image</label>
                                        <div class="form-group">
                                            <img src="/storage/images/users/<?php echo e($user->image, false); ?>"
                                                 style="width: 200px;height: 200px">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Show User')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Digital Edge Projects\chat\resources\views/users/show.blade.php ENDPATH**/ ?>